<?php 
session_start(); 
if(isset($_SESSION['mail'])&&isset($_SESSION['password'])){ 
    $var=$_SESSION['mail']; 
    $mot=$_SESSION['password']; 
    } 
    else { header('Location:seconnect.php'); } 
    //connexion avec le serveur (APACHE) 
    $username = "root"; 
    $password = ""; 
    $hostname = "localhost"; 
    // activer le rapport d'erreur 
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); 
    // connection string with database 
    $dbhandle = mysqli_connect($hostname, $username, $password); 
    // connect with table 
    $selected = mysqli_select_db($dbhandle, "ma base"); 
    // Query the database to check if the user exists 
    $sql = "SELECT * FROM user WHERE mail='$var' AND password='$mot'"; 
    $result = mysqli_query($dbhandle, $sql); 
    // stocker les donnees dans une ligne d'un tableau 
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC); ?> 
    <!DOCTYPE html> 
    <html lang="en"> 
        <head> 
            <meta charset="UTF-8"> 
            <!-- Basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <!-- Site Metas -->
   <title>ISI KEF</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- site icon -->
   <link rel="icon" href="images/fevicon.png" type="image/png" />
   <!-- Bootstrap core CSS -->
   <link href="css/bootstrap.css" rel="stylesheet">
   <!-- FontAwesome Icons core CSS -->
   <link href="css/font-awesome.min.css" rel="stylesheet">
   <!-- Custom animate styles for this template -->
   <link href="css/animate.css" rel="stylesheet">
   <!-- Custom styles for this template -->
   <link href="style.css" rel="stylesheet">
   <!-- Responsive styles for this template -->
   <link href="css/responsive.css" rel="stylesheet">
   <!-- Colors for this template -->
   <link href="css/colors.css" rel="stylesheet">
   <!-- light box gallery -->
   <link href="css/ekko-lightbox.css" rel="stylesheet">
   <!--[if lt IE 9]>
   <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
   <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
   <![endif]-->
            <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
            <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
            <title>Espace étudiant</title> 
        </head> 
        <body id="home_page" class="home_page">
      <!-- header -->
            <B>Welcome <?php echo $row['Nom']; echo " "; echo $row['Prenom'];?></B> 
      <header class="header">
        <div class="header_top_section">
           <div class="container">
              <div class="row">
               <div class="col-lg-3">
                  <div class="full">
                     <div class="logo">
                        <a href="index.php"><img src="images/logo.gif" alt="#" /></a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-9 site_information">
                  <div class="full">
                     <div class="main_menu">
                        <nav class="navbar navbar-inverse navbar-toggleable-md">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#cloapediamenu" aria-controls="cloapediamenu" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="float-left">Menu</span>
                           <span class="float-right"><i class="fa fa-bars"></i> <i class="fa fa-close"></i></span>
                           </button>
                           <div class="collapse navbar-collapse justify-content-md-center" id="cloapediamenu">
                              <ul class="navbar-nav">
                                 <li class="nav-item active">
                                    <a class="nav-link" href="index.php">Accueil</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-aqua-hover" href="apropos.php">A propos de nous </a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-aqua-hover" href="espacee.php">Espace enseignant</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-grey-hover" href="vieet.php">Vie etudiantine</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-grey-hover" href="logout.php">Se déconnecter</a>
                                 </li>
                              </ul>
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
           </div>
        </div>

      </header>
      <!-- end header -->
      
      <!-- section -->
      <section class="main_full banner_section_top">
        <div class="container-fluid">
          <div class="row">
             <div class="full">
                  <div class="slider_banner">
                    <img class="img-responsive" src="images/hole.jpg" alt="#" />
                      <div class="slide_cont">
                        <div class="slider_cont_inner">
                          <h3>Bienvenue</h3>
                          <center>
                        <p> L’Institut  Supérieur d’Informatique du Kef a été crée selon le décret n°06-1587 du 6 juin 2006 portant création d’établissements  d’enseignement supérieur et de recherche.
        
                           En effet, l’ISIKef est l’une des établissements universitaires de l’université de Jendouba.
                           </p>
                        </center>
                        </div>
                      </div>
                  </div>
                </div>
          </div>
        </div>
      </section>
      <!-- end section -->
    
     <!-- about section -->
      <section class="layout_padding section about_dottat">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>Mot du Directeur
                     </h2>
                  </div>
                  <div class="full">
                     <p class="large">Je vous souhaite la bienvenue sur le site web de l’Institut Supérieur d’Informatique du Kef.

                        Ce site s'enrichit régulièrement pour vous fournir les informations que vous cherchez. Que vous soyez visiteur, étudiant, personnel, enseignant, administratif ou technique, que vous cherchiez des informations sur notre offre de formation, sur les examens, sur les stages, sur l'actualité de l’institut, ... , ce site est fait pour vous.
                        
                        Notre Institut est reconnu pour la qualité de ses formations. Il attire chaque année plus d'étudiants et leur offre des cursus et débouchés variés.
                        
                        Notre plateforme est conçue pour être un espace d’échange vous donnant une image aussi fidèle que possible de ce que nous sommes et de ce qui vous attend. Votre opinion nous tient à cœur, car elle nous aidera à maintenir notre site vivant et à améliorer sa qualité.
                        
                        Nous espérons que la présente visite saura répondre à toutes vos attentes et interrogations, mais par-dessus tout aiguiser votre curiosité au point de communiquer avec nous. Il s’agit d’une première démarche, mais nous anticipons déjà le plaisir de vous accueillir au sein de notre institut. Il nous fera plaisir de vous accompagner tout au long de votre parcours à la recherche de l’information dont vous avez besoin.
                        
                        L’équipe de direction de l’Institut Supérieur d’Informatique du Kef vous souhaite une bonne visite de ce site.
                        
                        <h5><br>Très cordialement<br></h5>
                        
                        <h5>Hayouni Mohamed<br></h5>
                        
                        <h5>Directeur de l’Institut Supérieur d’Informatique du Kef</p></h5>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="about_img margin_top_30  text_align_center">
                     <img src="images/mrhayouni.jpg" alt="#" />
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end about section -->

      <!-- section -->
      <section class="layout_padding section">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>Nos formation </h2>
                  </div>
               </div>
            </div>
            <div class="row">

              <div class="col-md-4 text_align_center">
                 <h3>LCS</h3>
                 <p>
                  Cette Licence Intitulé "Computer Science" Comprend Deux Spécialités :
                  Génie Logiciel Et Système D'Information : GL
                  Informatique et Multimédia : IM</p>
              </div>  

              <div class="col-md-4 text_align_center">
                 <h3>LCE</h3>
                 <p>Licence en Computer Engineering
                  Cette Licence Contient une seule Spécialité : Ingénierie des réseaux et systèmes</p>
              </div> 

              <div class="col-md-4 text_align_center">
                 <h3>SIW</h3>
                 <p>Mastère de Recherche en Systèmes d'Informations et Web
                  Plan d'études du Mastère de recherche en systèmes d'informations et web</p>
              </div> 

              <div class="col-md-4 text_align_center">
               <h3>ASRI</h3>
               <p>Mastère Professionnel en Administration et Sécurité des Réseaux Informatiques</p>
            </div> 

            <div class="col-md-4 text_align_center">
               <h3>AWI</h3>
               <p>Mastère Professionnel en Application Web Intelligente</p>
            </div> 

            <div class="col-md-4 text_align_center">
               <h3>NTCIDIA</h3>
               <p>Mastère Co-Construite en Nouvelles Technologies de l’Information et de la Communication dédiées à l'Innovation de l'Agriculture</p>
            </div> 
            </div>
         </div>
      </section>
      <!-- end section -->

      <!-- section -->
      <section class="layout_padding section">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>Organigramme administratif</h2>
                  </div>
               </div>
               <div class="col-md-12 testimonial">
                  <div class="full text_align_center">
                     <img src="images/organigramme.jpg" alt="#" />
               </div>
            </div>
        </div>
      </section>
      <!-- end section -->

    
      <!-- section -->
      <section class="section blue_pattern_bg" style="background-color: #3b3bff;">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="full">
                     <h4>Regoignez notre Newsletter !</h4>
                  </div>
               </div>
               <div class="col-md-6">
                 <div class="form_subribe">
                    <form>
                       <input type="email" name="email" placeholder="Entrez votre Email" />
                       <button>Isncrire</button>
                    </form>
                 </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end section -->
     
      <!-- footer -->
      <footer class="footer layout_padding">
         <div class="container">
            <div class="row">

               <div class="col-md-4 col-sm-12">
                  <a href="index.php"><img class="img-responsive" src="images/logo.gif" alt="#" /></a>
                  <div class="footer_link_heading">
                     <div class="footer_menu margin_top_30">
                     <ul>
                        <li><a href="tel:9876543210">Tél : (216) 78 201 056<br>
                           Fax : (216) 78 200 237</a></li>
                        <li><a href="#">Adresse : 5 Rue Saleh Ayech - 7100 Kef </a></li>
                     </ul>
                  </div>
                  </div>
               </div>
               
            </div>
         </div>
      </footer>
      <div class="cpy">
        <div class="container">
           <div class="row">
             <div class="col-md-12">
               <p>© Tous droits réservés 2023 ISIKEF</p>
             </div>
           </div>
        </div>
      </div>
      <!-- end footer -->
      <!-- Core JavaScript
         ================================================== -->
      <script src="js/jquery.min.js"></script>
      <script src="js/tether.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/parallax.js"></script>
      <script src="js/animate.js"></script>
      <script src="js/ekko-lightbox.js"></script>
      <script src="js/custom.js"></script>
        </body> 
        </html>